package com.example.roomsbuddy.view.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.roomsbuddy.R;
import com.example.roomsbuddy.data.ViewPagerAdapter;
import com.example.roomsbuddy.databinding.FragmentHomeBinding;
import com.google.android.material.tabs.TabLayout;

public class HomeFragment extends Fragment {
    private ViewPagerAdapter viewPagerAdapter;
    private FragmentHomeBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding=FragmentHomeBinding.inflate(getLayoutInflater());
        viewPagerAdapter = new ViewPagerAdapter(getActivity().getSupportFragmentManager());
        viewPagerAdapter.add(new OptionFragment(), "Trending");
        viewPagerAdapter.add(new OptionFragment(), "Promotion");
        viewPagerAdapter.add(new OptionFragment(), "Favorites");
        binding.viewpager.setAdapter(viewPagerAdapter);
        binding.tabLayout.setupWithViewPager(binding.viewpager);
        return binding.getRoot();

    }
}