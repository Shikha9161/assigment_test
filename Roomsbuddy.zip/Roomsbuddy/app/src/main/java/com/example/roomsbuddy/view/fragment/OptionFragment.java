package com.example.roomsbuddy.view.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.roomsbuddy.R;
import com.example.roomsbuddy.data.Adapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;


public class OptionFragment extends Fragment {
    List<String> hotelNameList;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    Adapter adapter;
    LinearLayoutManager HorizontalLayout;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_option, container, false);
        recyclerView = view.findViewById(R.id.recyclerview);
        hotelNameList = new ArrayList<>();
        hotelNameList.add("UMAID BHAWAN PALACE JODHPUR");
        hotelNameList.add("THE OBEROI NEW DELHI");
        hotelNameList.add("TAJ LAKE PALACE, UDAIPUR");
        hotelNameList.add("THE OBEROI AMARVILAS");
        hotelNameList.add("TAJ FALAKNUMA PALACE, HYDERABAD");
        hotelNameList.add("ANANDA IN THE HIMALAYAS");
        hotelNameList.add("THE TAJ MAHAL PALACE MUMBAI");
        adapter = new Adapter(hotelNameList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(adapter);
        return view;
    }
}